from django.apps import AppConfig


class LocationAppConfig(AppConfig):
    name = 'location_app'
