from django.db import models

# Create your models here.



class BusNo(models.Model):

    name = models.CharField(max_length=100,blank=True,null=True)

    def __str__(self):
        return self.name



class Lat_Long(models.Model):
    busno = models.ForeignKey(BusNo,on_delete=models.CASCADE,blank=True,null=True)
    latitude = models.CharField(max_length=100,blank=True)
    longitude = models.CharField(max_length=100,blank=True)
    address = models.CharField(max_length=1000,blank=True,null=True)


    def __str__(self):
        return str(self.busno.name)




