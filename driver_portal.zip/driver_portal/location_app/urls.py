
from django.urls import path, re_path, include
from . import views


urlpatterns = [

    path('index/<key>/',views.index),
#     re_path('pos/' views.position,name="pos"),
    re_path("pos/",views.position,name="pos"),

    re_path("location/",views.details,name="det"),
    re_path("ap/",views.ap),
 ]
