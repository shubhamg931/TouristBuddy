from django.conf.urls import url, include
from django.contrib.auth.models import User
from rest_framework import routers, serializers, viewsets

from .models import BusNo,Lat_Long



class Lat_lng_serilizers(serializers.ModelSerializer):

    class Meta:
        model = Lat_Long
        fields = '__all__'



class BusNoSerializer(serializers.ModelSerializer):


    class Meta:
        model = BusNo
        fields = '__all__'

