from django.contrib import admin
from .models import BusNo,Lat_Long



# Register your models here.

admin.site.register(BusNo)
admin.site.register(Lat_Long)
