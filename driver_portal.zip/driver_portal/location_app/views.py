from django.http import HttpResponseForbidden,HttpResponse
from django.shortcuts import render
from hashlib import sha256



from .models import BusNo,Lat_Long

from .serializers import Lat_lng_serilizers

from .utils import calc,stand_data
import time

import json


from django.views.decorators.csrf import csrf_exempt

api_key="rajasthan_hacks"
api_key=api_key.encode("utf-8")
api_key=sha256(api_key).hexdigest()[10:20]







def index(request,key):
    if key==api_key:
        return render(request,'location_app/loc.html')

    return HttpResponseForbidden("You are not authorized to access this software")






def ap(request):

    obj = Lat_Long.objects.all()
    li = []
    for i in obj:

        di =  {"name":i.address,
               "details":{
                   "line":i.busno.name,
                   "latitude":i.latitude,
                   "Longitude":i.longitude,
               }

               }
        li.append(di)

    return HttpResponse(json.dumps(li),content_type="text/javascript")




@csrf_exempt
def position(request):
    if request.method == "POST":
        data = request.POST.dict()
        print(request.POST.dict())
        if BusNo.objects.filter(busno = data["bus_no"]).exists():
            bobj = BusNo.objects.filter(busno = data["bus_no"])[0]
        else:
            bobj = BusNo(busno=data["bus_no"])
            bobj.save()
        del data["bus_no"]
        data["busno"] = bobj

        obj = Lat_Long(**data)
        obj.save()

        return  HttpResponse("success")
    else:
        return HttpResponse("get request is not accepted")





@csrf_exempt
def details(request):
    if request.method == "POST":
        data = json.loads(request.body.decode("utf-8"))

        start = data["start_point"]
        end = data["end_point"]
        lat1 = start[0]
        lat2 = end[0]
        lang1 = start[1]
        lang2 = end[1]

        p,dest = calc(lat1,lang1,lat2,lang2)
        listi = []
        for i in p:
            for j in stand_data:
                if j["name"] == i:
                    listi.append(j)


        print(listi)

        return HttpResponse(json.dumps(listi),content_type="text/javascript")

    else:
        return HttpResponse("Get request is not allowed")

