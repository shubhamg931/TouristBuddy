from collections import defaultdict, deque
from math import radians, sin, cos, acos, atan2, sqrt

stand_data = [{'name': 'Bikaner Central Jail', 'details': {'line': '101A', 'latitude': '28.0400059', 'longitude': '73.2766055'}}, {'name': 'Regional Transport Office', 'details': {'line': '101A', 'latitude': '28.0859121', 'longitude': '73.3562944'}}, {'name': 'NRI Residential Twp', 'details': {'line': '101A', 'latitude': '28.0792238', 'longitude': '73.3436414'}}, {'name': 'Fauji Dhaba', 'details': {'line': '101A', 'latitude': '28.0635331', 'longitude': '73.3393627'}}, {'name': 'Mataji Mandir 10th Rac', 'details': {'line': '101A', 'latitude': '28.0543562', 'longitude': '73.3355442'}}, {'name': 'Government Dungar college', 'details': {'line': '101A', 'latitude': '28.018793', 'longitude': '73.3269554'}}, {'name': 'Paradise Park', 'details': {'line': '101A', 'latitude': '28.004686', 'longitude': '73.3309569'}}, {'name': 'Women Police Station', 'details': {'line': '101A', 'latitude': '28.0083113', 'longitude': '73.3370598'}}, {'name': 'Maharaja Ganga University', 'details': {'line': '102A', 'latitude': '28.0266862', 'longitude': '73.2651396'}}, {'name': 'Dudi Honda Showroom', 'details': {'line': '102A', 'latitude': '28.0261431', 'longitude': '73.272419'}}, {'name': 'Suraj Market', 'details': {'line': '102A', 'latitude': '28.0211179', 'longitude': '73.2869073'}}, {'name': 'Vaidya Mangaram Colony', 'details': {'line': '102A', 'latitude': '28.0231096', 'longitude': '73.3003782'}}, {'name': 'Head Post Office', 'details': {'line': '102A', 'latitude': '28.0207418', 'longitude': '73.3093261'}}, {'name': 'Children Train', 'details': {'line': '102A', 'latitude': '28.0207418', 'longitude': '73.3093261'}}, {'name': 'Ganga State Museum', 'details': {'line': '102A', 'latitude': '28.0185635', 'longitude': '73.3237027'}}, {'name': 'Commissioner Colonisation Department', 'details': {'line': '102A', 'latitude': '28.0173682', 'longitude': '73.3436358'}}, {'name': 'Central Public Works Department', 'details': {'line': '102A', 'latitude': '28.0177027', 'longitude': '73.3589188'}}, {'name': 'Bikaner Motors Private Limited', 'details': {'line': '102A', 'latitude': '28.0258347', 'longitude': '73.3836928'}}, {'name': 'HP Petrol Pump - Bikaner Filling Station', 'details': {'line': '102A', 'latitude': '28.0295446', 'longitude': '73.3962862'}}, {'name': 'Yashoda Nagar', 'details': {'line': '102A', 'latitude': '28.0305625', 'longitude': '73.4007892'}}, {'name': 'Krishi Upaj Mandi', 'details': {'line': '103A', 'latitude': '28.0440775', 'longitude': '73.3172045'}}, {'name': 'Additional Chief Engineer, PHED', 'details': {'line': '103A', 'latitude': '28.0379064', 'longitude': '73.3237881'}}, {'name': 'Ganganagar Choraha Bikaner', 'details': {'line': '103A', 'latitude': '28.0332891', 'longitude': '73.3249363'}}, {'name': 'Pt. Deen Dayal Upadhyaya Circle', 'details': {'line': '103A', 'latitude': '28.0259912', 'longitude': '73.3283557'}}, {'name': 'Sadar Police Thana', 'details': {'line': '103A', 'latitude': '28.0230854', 'longitude': '73.3279985'}}, {'name': 'Bapu Colony', 'details': {'line': '103A', 'latitude': '28.0191216', 'longitude': '73.3228672'}}, {'name': 'Govt. Polytechnic College, Bikaner', 'details': {'line': '103A', 'latitude': '28.0068082', 'longitude': '73.3336819'}}, {'name': 'Bikaner Nursing Home', 'details': {'line': '103A', 'latitude': '27.9988511', 'longitude': '73.3375443'}}, {'name': 'Sudarshana Nagar', 'details': {'line': '103A', 'latitude': '27.988942', 'longitude': ' 73.342136'}}]
count = 0
di = {}
for i in stand_data:
    di[str(count)] = i["name"]
    name = i["name"]
    di[name] = count
    count = count+1

# print(di)

route_data = [{'line': '101A', 'details': {'list_of_stands': ['Bikaner Central Jail', 'Regional Transport Office', 'NRI Residential Twp', 'Fauji Dhaba', 'Mataji Mandir 10th Rac', 'Government Dungar college', 'Paradise Park', 'Women Police Station']}}, {'line': '102A', 'details': {'list_of_stands': ['Maharaja Ganga University', 'Dudi Honda Showroom', 'Suraj Market', 'Vaidya Mangaram Colony', 'Head Post Office', 'Children Train', 'Ganga State Museum', 'Commissioner Colonisation Department', 'Central Public Works Department', 'Bikaner Motors Private Limited', 'HP Petrol Pump - Bikaner Filling Station', 'Yashoda Nagar']}}, {'line': '103A', 'details': {'list_of_stands': ['Krishi Upaj Mandi', 'Additional Chief Engineer, PHED', 'Ganganagar Choraha Bikaner', 'Pt. Deen Dayal Upadhyaya Circle', 'Sadar Police Thana', 'Bapu Colony', 'Govt. Polytechnic College, Bikaner', 'Bikaner Nursing Home', 'Sudarshana Nagar']}}]


import json
from collections import defaultdict, deque
from math import radians, sin, cos, acos, atan2, sqrt
R = 6373.0



class Graph(object):
    def __init__(self):
        self.nodes = set()
        self.edges = defaultdict(list)
        self.distances = {}

    def add_node(self, value):
        self.nodes.add(value)

    def add_edge(self, from_node, to_node, distance):
        self.edges[from_node].append(to_node)
        self.edges[to_node].append(from_node)
        self.distances[(from_node, to_node)] = distance


def dijkstra(graph, initial):
    visited = {initial: 0}
    path = {}

    nodes = set(graph.nodes)
    # print(graph.nodes)
    # print("#######################################################")
    # print(nodes)

    while nodes:
        min_node = None
        for node in nodes:
            if node in visited:
                if min_node is None:
                    min_node = node
                elif visited[node] < visited[min_node]:
                    min_node = node
        #print(nodes)
        if min_node is None:
            break

        nodes.remove(min_node)
        current_weight = visited[min_node]

        for edge in graph.edges[min_node]:
            try:
                weight = current_weight + graph.distances[(min_node, edge)]
            except:
                continue
            if edge not in visited or weight < visited[edge]:
                visited[edge] = weight
                path[edge] = min_node
    # print(path)
    return visited, path


def distance(lat1,lon1,lat2,lon2,p):
    lat1 = float(lat1)
    lon1 = float(lon1)
    lat2 = float(lat2)
    lon2 = float(lon2)
    dlon = float(lon2) - float(lon1)
    dlat = float(lat2) - float(lat1)
    a = (sin(dlat/2))**2 + cos(lat1) * cos(lat2) * (sin(dlon/2))**2
    #print(a)
    #print("he;l",type(a))
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    distance = R * c
    # if(p==1):
    #     print(distance,dlat,dlon,lat1,lon1,lat2,lon2)
    return distance


def shortest_path(graph, origin, destination):
    visited, paths = dijkstra(graph, origin)
    full_path = deque()
    try:
        _destination = paths[destination]
    except Exception as e:
        return None, {}


    while _destination != origin:
        full_path.appendleft(_destination)
        _destination = paths[_destination]

    full_path.appendleft(origin)
    full_path.append(destination)

    # print(visited[destination])
    return visited[destination], list(full_path)


def calc(ulat1,ulang1,ulat2,ulang2):
    graph = Graph()

    # print(shortest_path(graph, 'A', 'D')) # output: (25, ['A', 'B', 'D'])

    for line in route_data:
        stations = line["details"]["list_of_stands"]
        # stations = json.loads(stations.replace("'",'"'))
        for station in stations:
            # print(station,di[station],end=" ")
            # print(di[station])
            graph.add_node(di[station])

    for line in route_data:
        stations = line["details"]["list_of_stands"]
        # stations = json.loads(stations.replace("'",'"'))
        for i in range(len(stations) - 1):
            # print(stations[i],di[stations[i]],end=" ")

            lat1 = stand_data[di[stations[i]]]["details"]["latitude"]
            lng1 = stand_data[di[stations[i]]]["details"]["longitude"]

            lat2 = stand_data[di[stations[i + 1]]]["details"]["latitude"]
            lng2 = stand_data[di[stations[i + 1]]]["details"]["longitude"]

            graph.add_edge(di[stations[i]], di[stations[i + 1]],
                           distance(float(lat1), float(lng1), float(lat2), float(lng2),0))
            graph.add_edge(di[stations[i + 1]], di[stations[i]],
                           distance(float(lat1), float(lng1), float(lat2), float(lng2),0))


    dist = 1000000000
    origin = ""
    for line in route_data:
        stations = line["details"]["list_of_stands"]
        # stations = json.loads(stations.replace("'",'"'))
        for i in range(len(stations)):
            # print(stations[i],di[stations[i]],end=" ")

            lat = stand_data[di[stations[i]]]["details"]["latitude"]
            lng = stand_data[di[stations[i]]]["details"]["longitude"]

            dst = distance(ulat1,ulang1,lat,lng,0)
            if(dst < dist):
                # print(stations[i])
                distance(ulat1, ulang1, lat, lng,1)
                dist = dst
                origin = stations[i]

    dist = 1000000000
    destination = ""
    for line in route_data:
        stations = line["details"]["list_of_stands"]
        # stations = json.loads(stations.replace("'",'"'))
        for i in range(len(stations)):
            # print(stations[i],di[stations[i]],end=" ")

            lat = stand_data[di[stations[i]]]["details"]["latitude"]
            lng = stand_data[di[stations[i]]]["details"]["longitude"]

            dst = distance(ulat2,ulang2,lat,lng,0)
            if(dst < dist):
                # print(stations[i])
                distance(ulat2, ulang2, lat, lng,1)
                dist = dst
                destination = stations[i]
    print(origin,destination)


    dest, path = shortest_path(graph, di[origin], di[destination])

    for station in path:
        print(di[str(station)], end=" ")

#if __name__ == '__main__':

calc(28.0400059,73.2766055,28.018793,73.3269554)